package com.codeoracle.demo;

import java.util.HashMap;
import java.util.Map;

public class UserRepository {
    private final Map<String, User> store = new HashMap<>();

    public UserRepository() {
        store.put("u100", new User("u100", "Alice", "alice@example.com"));
        store.put("u200", new User("u200", "Bob", "bob@example.com"));
    }

    public User findById(String id) {
        return store.get(id);
    }
}
