package com.codeoracle.demo;

public class UserService {
    private final UserRepository repository = new UserRepository();

    public User getUserById(String id) throws UserNotFoundException {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("User ID cannot be blank");
        }
        User user = repository.findById(id);
        if (user == null) {
            throw new UserNotFoundException("User not found with ID: " + id);
        }
        return user;
    }

    public boolean authenticate(String id, String token) {
        AuthManager auth = new AuthManager();
        return auth.validateSession(id, token);
    }
}
