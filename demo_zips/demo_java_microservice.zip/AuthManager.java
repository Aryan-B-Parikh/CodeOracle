package com.codeoracle.demo;

public class AuthManager {
    public boolean validateSession(String userId, String token) {
        if (token == null || !token.startsWith("tok_")) {
            return false;
        }
        try {
            UserService service = new UserService();
            User u = service.getUserById(userId);
            return u != null;
        } catch (UserNotFoundException e) {
            return false;
        }
    }
}
