"""Payment gateway integration."""

class PaymentGatewayError(Exception):
    """Raised when payment transaction is declined or network error occurs."""
    pass

def process_credit_card(customer_id: str, card_number: str, amount: float) -> str:
    """Charges customer card via payment gateway."""
    if not card_number or len(card_number) < 12:
        raise PaymentGatewayError("Invalid credit card number format")
    if amount <= 0:
        raise PaymentGatewayError("Transaction amount must be positive")
    return f"tx_chg_{customer_id[:4]}_{int(amount)}"

def refund_transaction(transaction_id: str, amount: float) -> bool:
    """Refunds previously processed transaction."""
    if not transaction_id.startswith("tx_chg_"):
        return False
    return True
