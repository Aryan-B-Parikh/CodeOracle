"""Inventory management service."""
from orders import calculate_order_total

_STOCK_DB = {"item_1": 100, "item_2": 50, "item_3": 0}

def check_stock(items: list[dict]) -> bool:
    """Verifies all requested items have sufficient inventory stock."""
    for item in items:
        item_id = item.get("id")
        quantity = item.get("quantity", 1)
        if _STOCK_DB.get(item_id, 0) < quantity:
            return False
    return True

def reserve_items(items: list[dict]) -> None:
    """Deducts reserved item quantities from in-memory stock."""
    for item in items:
        item_id = item.get("id")
        quantity = item.get("quantity", 1)
        if item_id in _STOCK_DB:
            _STOCK_DB[item_id] -= quantity

def estimate_restock_cost(items: list[dict]) -> float:
    """Estimates restocking cost by consulting order total calculation."""
    return calculate_order_total(items, discount_code="VIP20")
