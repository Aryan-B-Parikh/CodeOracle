"""Order management service."""
from inventory import check_stock, reserve_items
from payment import process_credit_card, PaymentGatewayError

def calculate_order_total(items: list[dict], discount_code: str | None = None, tax_rate: float = 0.08) -> float:
    """Calculates order total with multi-tier conditional tax, discounts, and validation."""
    if not items:
        raise ValueError("Order must contain at least one item")
    
    subtotal = 0.0
    for item in items:
        price = item.get("price", 0.0)
        quantity = item.get("quantity", 1)
        if price < 0 or quantity <= 0:
            raise ValueError("Invalid item price or quantity")
        subtotal += price * quantity
    
    discount = 0.0
    if discount_code == "SAVE10":
        discount = subtotal * 0.10
    elif discount_code == "VIP20":
        discount = subtotal * 0.20
    elif discount_code == "FLAT50" and subtotal > 200.0:
        discount = 50.0
    
    discounted_subtotal = max(0.0, subtotal - discount)
    tax = discounted_subtotal * tax_rate
    total = discounted_subtotal + tax
    return round(total, 2)

def process_order(customer_id: str, items: list[dict], card_number: str) -> dict:
    """Places an order, reserves inventory, and charges customer card."""
    if not check_stock(items):
        return {"status": "out_of_stock", "order_id": None}
    
    total = calculate_order_total(items)
    try:
        charge_id = process_credit_card(customer_id, card_number, total)
        reserve_items(items)
        return {"status": "success", "charge_id": charge_id, "total": total}
    except PaymentGatewayError as exc:
        return {"status": "payment_failed", "error": str(exc)}
