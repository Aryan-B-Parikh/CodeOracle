"""Customer profile models."""

class Customer:
    """Base customer account representation."""
    def __init__(self, customer_id: str, email: str, tier: str = "standard"):
        self.customer_id = customer_id
        self.email = email
        self.tier = tier

    def get_discount_tier(self) -> str:
        return "SAVE10" if self.tier == "silver" else "NONE"

class VIPCustomer(Customer):
    """VIP Tier Customer with elevated discount privileges."""
    def __init__(self, customer_id: str, email: str):
        super().__init__(customer_id, email, tier="vip")

    def get_discount_tier(self) -> str:
        return "VIP20"
