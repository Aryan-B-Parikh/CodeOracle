"""Data ingestion and log extraction."""
import json

def fetch_raw_logs() -> list[str]:
    """Retrieves raw web server access logs."""
    return [
        '{"timestamp": "2026-08-14T10:00:00Z", "endpoint": "/api/v1/search", "status": 200, "latency_ms": 45}',
        '{"timestamp": "2026-08-14T10:00:01Z", "endpoint": "/api/v1/checkout", "status": 500, "latency_ms": 1200}',
        '{"timestamp": "2026-08-14T10:00:02Z", "endpoint": "/api/v1/products", "status": 200, "latency_ms": 30}'
    ]

def parse_log_line(raw_line: str) -> dict:
    """Parses JSON log string into structured dictionary."""
    try:
        return json.loads(raw_line)
    except json.JSONDecodeError:
        return {}
