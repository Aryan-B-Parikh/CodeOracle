"""ETL metric transformations."""
from extract import parse_log_line

def aggregate_metrics(raw_logs: list[str]) -> dict:
    """Aggregates request counts, errors, and average latency from raw log stream."""
    total_requests = 0
    error_count = 0
    total_latency = 0.0

    for raw in raw_logs:
        record = parse_log_line(raw)
        if not record:
            continue
        total_requests += 1
        if record.get("status", 200) >= 400:
            error_count += 1
        total_latency += float(record.get("latency_ms", 0.0))

    avg_latency = (total_latency / total_requests) if total_requests > 0 else 0.0
    error_rate = (error_count / total_requests) if total_requests > 0 else 0.0

    return {
        "total_requests": total_requests,
        "error_count": error_count,
        "error_rate": round(error_rate, 4),
        "avg_latency_ms": round(avg_latency, 2)
    }
