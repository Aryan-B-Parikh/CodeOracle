"""ETL Pipeline Orchestrator."""
from extract import fetch_raw_logs
from transform import aggregate_metrics
from load import write_summary_report

def run_etl_job() -> dict:
    """Executes end-to-end Extract-Transform-Load pipeline workflow."""
    logs = fetch_raw_logs()
    metrics = aggregate_metrics(logs)
    success = write_summary_report(metrics)
    return {"success": success, "metrics": metrics}
